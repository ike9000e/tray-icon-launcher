#include "tlv_entrypoint.h"
#include <assert.h>
#include <memory>

const char* szAppName = "TIL2 - Tray Icon Launcher";
const char* szUsage =
		"\n"
		"%s\n"
		"%s\n"
		"\n"
		"    Launches executables and provides the minimize-to-tray functionality.\n"
		"    Meant to be run from batch scripts or from command prompt.\n"
		"    If no command line progream provided, starts a hard-coded\n"
		"    execuatable with name '%s'.\n"
		"    This is for hex editing (NB. this may be hexed alrady)\n"
		"    Using '-C1' option may be used to instruct the CMD \n"
		"    to create its own, new console.\n"
		"\n"
		"Features\n"
		"-----------\n"
		"    * Tray minimize the CMD console. Has option to search \n"
		"      for CMD in the parent or child process list.\n"
		"    * Tray minimize window the command creates.\n"
		"    * Provide DLL and attach it to the starting process.\n"
		"    * Shows icon in the system tray.\n"
		"    * Handles Ctrl+C and auto unhides the window.\n"
		"\n"
		"    Build: %s, %s-bit\n"
		"\n"
		"Usage\n"
		"-------\n"
		"    program.exe [OPTIONS] -- {COMMAND}\n"
		"\n"
		"OPTIONS\n"
		"---------\n"
		"    -T3 - Move to the tray: window that the command creates.\n"
		"    -T2 - Move to the tray: first CMD window from the\n"
		"          child process list.\n"
		"    -T1 - Move to the tray: first CMD window from the\n"
		"          parent process list.\n"
		"    -S1 - Don't hide the helper window that the program \n"
		"          uses inernally. It's created only with \n"
		"          the -T1 -T2 or -T3 option.\n"
		"    -S2 - Show options being used.\n"
		"    -W0 - Don't wait for the command to finish.\n"
		"    -W1 - Wait for the command to finish. The default.\n"
		"    -DL FILE\n"
		"        - Provide a DLL file that is attached|injected to\n"
		"          the created process.\n"
		"    -C1 - Instruct CLI program that it should recieve its \n"
		"          own, new console window. Eg. if the command is CMD,\n"
		"          it starts with the new command prompt.\n"
		"    -TI - Move the window (or command prompt) to the \n"
		"          tray, initially.\n"
		"\n"
		"Examples\n"
		"----------\n"
		"    program.exe -T2 -W1 -C1 -TI -S1   -- cmd\n"
		"    program.exe -T2 -C1 -WN 8 -WI 200 -- cmd\n"
		"    program.exe -T1 -W1 -C1 -TI -S1   -- calc\n"
		"    program.exe -T1 -C1 -TI -S1       -- mpv.exe m.mkv\n"
		"    program.exe -T3 -S1               -- notepad\n"
		"    program.exe -W0                   -- notepad\n"
		"\n"
		"";
BOOL WINAPI TlvConsoleHandler( DWORD dwSignal )
{
	if( dwSignal == CTRL_C_EVENT ){
		HWND hwnd4 = TlvTrIcnMgr::pokeLastStaticHwnd();
		if( hwnd4 ){
			printf("TLV: Ctrl-C handled.\n");
			PostMessage( hwnd4, TlvTrIcnMgr::mWMDestroyLv2Id, 0, 0 );
			TlvTrIcnMgr::pokeLastStaticHwnd( 1L, 0 );
		}else{
			printf("TLV: Ctrl-C -> process exit.\n");
			return 0L;
		}
		return 1L;
	}
	return 0L;
}

/// Returns 1 on success.
/// Exit codes are 160+ if create process failed.
/// \param szCmd - either commandline here, or null - and all commandline
///                is passed via 'argv2' instead.
/// \param argv2 - see 'szCmd'.
bool tlv_ExecProcess( const char* szCmd,
		const std::vector<std::string>& argv2,
		bool bWait, bool bNoWindow, bool bNewConsole,
		int* nExitCode, const char* szDllNameIfAny,
		const TlvTrIcnDTO& sTricn3 )
{
	assert( !szCmd != argv2.empty() );
	std::string cmd2; DWORD exitCode = 0;
	STARTUPINFOA si2;
	PROCESS_INFORMATION pi2;
	ZeroMemory(&si2, sizeof(si2));
	ZeroMemory(&pi2, sizeof(pi2));
	si2.cb = sizeof(si2);
	if( !argv2.empty() ){
		for( auto a : argv2 ){
			a = ( !!strchr( a.c_str(), '\x20' ) ? ("\x22"+a+"\x22") : a );
			cmd2 += a + "\x20";
		}
	}else{
		cmd2 = szCmd;
	}
	std::shared_ptr<int> raii2( 0, [&]( int* ){
		if( pi2.hProcess ){ CloseHandle( pi2.hProcess ); pi2.hProcess = 0;}
		if( pi2.hThread ){  CloseHandle( pi2.hThread  ); pi2.hThread  = 0;}
		if( nExitCode ){ *nExitCode = (int)exitCode; }
	});
	//printf("TLV: Command-line: [%s]\n", cmd2.c_str() );

	// REF:
	// * CreateProcessA()
	//   https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessa
	// * Process Creation Flags
	//   https://learn.microsoft.com/en-us/windows/win32/procthread/process-creation-flags
	// dwCreationFlags:
	//     CREATE_NO_WINDOW(0x08000000): dont spawn the console for CLI programs.
	//         - this affects CLI processes, fe. the cmd.exe itself.
	//     CREATE_NEW_CONSOLE(0x00000010): affects CLI programs, fe. CMD.
	//         - without it, CMD runs in current window,
	//           ie. doesnt create it's own.

	//DetourCreateProcessWithDllEx()
	szDllNameIfAny = ( szDllNameIfAny && *szDllNameIfAny ? szDllNameIfAny : nullptr );
	bool rs2 = DetourCreateProcessWithDlls(
			nullptr, (char*)cmd2.c_str(),   //lpCommandLine
			nullptr, nullptr,
			1L,            //bInheritHandles,
			(bNewConsole ? CREATE_NEW_CONSOLE : 0) |
				(bNoWindow ? CREATE_NO_WINDOW : 0),  //dwCreationFlags
			nullptr, nullptr,
			&si2, &pi2,
			(szDllNameIfAny ? 1 : 0),
			(szDllNameIfAny ? &szDllNameIfAny : nullptr),
			CreateProcess );
	if( !rs2 ){
		std::string err2 = hxdw_GetLastError();
		printf("TLV: ERROR: failed creating new process [dJ05ZT]\n");
		printf("     Command: [%s]\n", cmd2.c_str() );
		printf("     Message: [%s]\n", err2.c_str() );
		exitCode = 160;
		return 0L;
	}
	assert( pi2.dwThreadId );
	assert( pi2.dwProcessId );
	if( sTricn3.bEnabled2 ){
		if( sTricn3.bCmdFirstParent ){
			HWND hw2 = (HWND)hxdw_FindParentCMDWindow( 0, nullptr, "o");
			assert( hw2 );
			TlvTrIcnMgr ti2( hw2, pi2.hProcess, sTricn3 );
			ti2.run2();
		}else if( sTricn3.bCmdFirstChild ){
			HWND hw3 = 0;
			DWORD pid3 = GetCurrentProcessId();
			for( int ii2=0; ii2 < sTricn3.nTrayminWaitNum; ii2++ ){
				if( (hw3 = (HWND)hxdw_FindChildCMDWindow( pid3, nullptr, "o" )) )
					break;
				printf("TLV: waiting2...\n");
				Sleep( sTricn3.nTrayminIntrvl );
			}
			assert( hw3 );
			TlvTrIcnMgr ti3( hw3, pi2.hProcess, sTricn3 );
			ti3.run2();
		}else{   //else regular process wait.
			HWND hwProc = 0;
			for( int ii2=0; ii2 < sTricn3.nTrayminWaitNum; ii2++ ){
				if( (hwProc = hxdw_FindMainWindowGivenPID( pi2.dwProcessId, "" )) )
					break;
				printf("TLV: waiting3...\n");
				Sleep( sTricn3.nTrayminIntrvl );
			}
			if( hwProc ){
				std::string sr2 = hxdw_GetWindowText( hwProc );
				printf("TLV: PID:%d, wnd: [%s]\n", (int)pi2.dwProcessId, sr2.c_str() );
				TlvTrIcnMgr ti4( hwProc, pi2.hProcess, sTricn3 );
				ti4.run2();
			}else{
				printf("TLV: ERROR: failed finding any window for PID:%d\n", (int)pi2.dwProcessId );
			}
		}
	}
	if( !bWait ){
		return 1L; //ok.
	}
	if( WAIT_FAILED == WaitForSingleObject( pi2.hProcess, INFINITE ) ){
		printf("TLV: ERROR: failed waiting for process to finish [3oXV6H]\n");
		exitCode = 161;
		return 0L;
	}
	bool rs3 = !!GetExitCodeProcess( pi2.hProcess, &exitCode );
	if(!rs3){ // if no exit code.
		printf("TLV: ERROR: failed getting process exit code [j8hHgl]\n");
		exitCode = 163;
		return 0L;
	}
	return 1L; //ok.
}
int main( int argc, const char*const* argv )
{
	std::string exec2, srDllNme2;
	const char* szHardExecName = "run_me_no_parameters.exe\0;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;";
	bool bWait = 1L, bFoundDblDash = 0L, bNoWindow = 0L;
	bool bNewConsole = 0L, bShowOptions = 0L;
	bool bHlp = 0L;
	TlvTrIcnDTO sTricn2;
	for( int ii2=1; ii2<argc; ii2++ ){
		bool bHlp2 = (
			!lstrcmpi( argv[ii2], "-h" ) || !lstrcmpi( argv[ii2], "-help" ) ||
			!lstrcmpi( argv[ii2], "--h" ) || !lstrcmpi( argv[ii2], "--help" ) ||
			!lstrcmpi( argv[ii2], "-?" ) || !lstrcmpi( argv[ii2], "/?" ) );
		if( bHlp2 ){
			bHlp = 1L;
			break;
		}
		if( bFoundDblDash ){
			const char* argx = argv[ii2];
			if( *argx ){
				exec2 += ( !exec2.empty() ? " " : "" );
				if( std::strchr( argx, '\x20' ) ){
					exec2 += ( std::string("\x22") + std::string(argx) + "\x22");
				}else{
					exec2 += argx;
				}
			}
			continue;
		}
		if(0){
		}else if( !lstrcmpi( argv[ii2], "--bWait") || !strcmp( argv[ii2], "-W1") ){
			bWait = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bNoWait") || !strcmp( argv[ii2], "-W0") ){
			bWait = 0L;
		}else if( !lstrcmpi( argv[ii2], "--bNoWindow") || !strcmp( argv[ii2], "-N") ){
			bNoWindow = 1L;
		}else if( !lstrcmpi( argv[ii2], "--Dll2") || !strcmp( argv[ii2], "-DL") ){
			srDllNme2 = (ii2+1 < argc ? argv[ii2+1] : "");
		}else if( !lstrcmpi( argv[ii2], "--bInitInTray") || !strcmp( argv[ii2], "-TI") ){
			sTricn2.bInitInTray = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bNewConsole") || !strcmp( argv[ii2], "-C1") ){
			bNewConsole = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bShowHlprWnd") || !strcmp( argv[ii2], "-S1") ){
			sTricn2.bShowHlprWnd = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bCMDTrIcnP") || !strcmp( argv[ii2], "-T1") ){
			sTricn2.bEnabled2 = 1L;
			sTricn2.bCmdFirstParent = 1L;
			sTricn2.bCmdFirstChild = 0L;
		}else if( !lstrcmpi( argv[ii2], "--bCMDTrIcnC") || !strcmp( argv[ii2], "-T2") ){
			sTricn2.bEnabled2 = 1L;
			sTricn2.bCmdFirstParent = 0L;
			sTricn2.bCmdFirstChild = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bTrIcnA") || !strcmp( argv[ii2], "-T3") ){
			sTricn2.bEnabled2 = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bShowOptions") || !strcmp( argv[ii2], "-S2") ){
			bShowOptions = 1L;
		}else if( !strcmp( argv[ii2], "--") ){
			bFoundDblDash = 1L;
		}else if( !lstrcmpi( argv[ii2], "--nTrayminWaitNum") || !strcmp( argv[ii2], "-WN") ){
			sTricn2.nTrayminWaitNum = ( ii2+1 < argc ? atoi( argv[ii2+1] ) : sTricn2.nTrayminWaitNum );
		}else if( !lstrcmpi( argv[ii2], "--nTrayminIntrvl") || !strcmp( argv[ii2], "-WI") ){
			sTricn2.nTrayminIntrvl = ( ii2+1 < argc ? atoi( argv[ii2+1] ) : sTricn2.nTrayminIntrvl );

		}else if( !lstrcmpi( argv[ii2], "--uWndTimerIntrvl") || !strcmp( argv[ii2], "-M1") ){
			sTricn2.uWndTimerIntrvl = ( ii2+1 < argc ? atoi( argv[ii2+1] ) : sTricn2.uWndTimerIntrvl );
		}
	}
	if( bHlp || argc <= 1 ){
		std::string sr2;
		sr2.resize( (size_t)strlen( szAppName )+2, '-');
		char bfrArchc[128] = {0,};
		snprintf( bfrArchc, sizeof(bfrArchc), "%d", (int)(sizeof(size_t)*8) );
		printf( szUsage, szAppName, sr2.c_str(), szHardExecName, __DATE__, bfrArchc );
		return 10;
	}
	//printf("TLV: Arch: %s\n",  );
	if( bShowOptions ){
		printf("TLV: Configuration:\n");
		printf("    bWait             : %d\n", (int)bWait );
		printf("    bNoWindow         : %d\n", (int)bNoWindow );
		printf("    bNewConsole       : %d\n", (int)bNewConsole );
		printf("    C.bEnabled2       : %d\n", (int)sTricn2.bEnabled2 );
		printf("    C.bCmdFirstParent : %d\n", (int)sTricn2.bCmdFirstParent );
		printf("    C.bCmdFirstChild  : %d\n", (int)sTricn2.bCmdFirstChild );
		printf("    C.bInitInTray     : %d\n", (int)sTricn2.bInitInTray );
		printf("    C.nTrayminWaitNum : %d\n", (int)sTricn2.nTrayminWaitNum );
		printf("    C.nTrayminIntrvl  : %d\n", (int)sTricn2.nTrayminIntrvl );
		printf("    C.bShowHlprWnd    : %d\n", (int)sTricn2.bShowHlprWnd );
	}
	if( exec2.empty() ){
		exec2 = szHardExecName;
	}
	if( !SetConsoleCtrlHandler( TlvConsoleHandler, 1L ) ){
		printf("TLV: ERROR: Could not set control handler [McGYEo]\n");
		return 151;
	}
	int nExitCode2 = 255;
	if( !tlv_ExecProcess( exec2.c_str(), {}, bWait, bNoWindow,
			bNewConsole, &nExitCode2, srDllNme2.c_str(),
			sTricn2 ) ){
		return nExitCode2;
	}
	if( bWait ){
		return nExitCode2;
	}
	return 0;
}

TlvTrIcnMgr::TlvTrIcnMgr( HWND hwManage_, HANDLE hCloseWith_, const TlvTrIcnDTO& cmdtricn_ )
	: hCloseWith(hCloseWith_)
	, hwManage(hwManage_)
	, mCmdtricn(cmdtricn_)
{
	memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
}
HWND TlvTrIcnMgr::mHwnd3 = 0;
TlvTrIcnMgr::~TlvTrIcnMgr()
{
	if( hwManage && bIsInTray ){
		toggleWindowVisibility( 0L );
	}
	if( mNid.hWnd ){
		Shell_NotifyIcon( NIM_DELETE, &mNid );
		memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
	}
}
void TlvTrIcnMgr::toggleWindowVisibility( int nShowInTray )
{
	assert( hwManage );
	if( nShowInTray == -1 ){
		nShowInTray = !!IsWindowVisible(hwManage);
	}
	if( nShowInTray ){
		ShowWindow(hwManage, SW_HIDE);//SW_MINIMIZE
		bIsInTray = 1L;
	}else{
		ShowWindow(hwManage, SW_SHOW);
		ShowWindow(hwManage, SW_RESTORE);
		SetForegroundWindow(hwManage);
		bIsInTray = 0L;
	}
}
LRESULT CALLBACK
WndProc2( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
	TlvTrIcnMgr* this2 = (TlvTrIcnMgr*)GetWindowLongPtr( hWnd, GWLP_USERDATA );
	if(this2){
		return this2->WndProc3( hWnd, message, wParam, lParam );
	}
	return DefWindowProc( hWnd, message, wParam, lParam );
}
LRESULT TlvTrIcnMgr::WndProc3( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
	if( message == mWMTrayMessageId ){
		if( TlvAny<int>( lParam, {WM_LBUTTONDOWN,WM_LBUTTONDBLCLK,} ) ){
			toggleWindowVisibility( -1 );
		}
	}else if( message == TlvTrIcnMgr::mWMDestroyLv2Id ){
		DestroyWindow(hWnd);
	}
	switch(message){
	case WM_COMMAND:{
			int wmId = LOWORD(wParam);
			int wmEvent = HIWORD(wParam);
			switch( wmId ){
			default:
				return DefWindowProc( hWnd, message, wParam, lParam );
			}
		}
		break;
	case WM_DESTROY:
		printf("TLV: Processing WM_DESTROY\n");
		PostQuitMessage(0);
		return 1L;
	case WM_KEYDOWN:{
			int nVirtKey = (int) wParam;    // virtual-key code
			if( nVirtKey == 'Q' ){
				// Ctrl+Q to quit, implementation.
				if( GetAsyncKeyState(VK_CONTROL) & 0x8000 ){
					DestroyWindow(hWnd);
				}
			}else if( nVirtKey == 'T' ){
				printf("T\n");
				this->setTimeout2( 1200, [](void*user2){
                    printf("T2, %d\n", (int)(size_t)user2 );
				}, (void*)42 );
			}
		}
		break;
	case WM_TIMER:{
			int nTimerID = wParam;
			if( nTimerID == mTimerClsWthId ){
				if( hCloseWith ){
					//printf("WM_TIMER_\n");
					if( WAIT_OBJECT_0 == WaitForSingleObject( hCloseWith, 0 ) ){
						DestroyWindow(hWnd);
					}
				}
			}else if( nTimerID == mTimerSetTmoId ){
				KillTimer( hWnd, mTimerSetTmoId );
				mTmoCalb( mTmoCalbUserVal );
			}
		}
		break;
	default:
		return DefWindowProc( hWnd, message, wParam, lParam );
	}
	return 0;
}
ATOM TlvTrIcnMgr::registerHlprWndClass( HINSTANCE hInstance )
{
	WNDCLASSEX wcex;
	memset( &wcex, 0, sizeof(wcex) );
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc2; //(WNDPROC)
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wcex.lpszMenuName = "Tlv_Helper_Class_C1wXxr";
	wcex.lpszClassName = "Tlv_Helper_Class_C1wXxr";
	//wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));
	return RegisterClassEx(&wcex);
}
/// Returns 0 on error.
uint32_t TlvTrIcnMgr::
setTimeout2( uint32_t nMillis, std::function<void(void*user2)> calb2, void* user2 )
{
	assert( !!calb2 );
	mTmoCalb = calb2;
	mTmoCalbUserVal = user2;

	assert( mHwnd );
	UINT idtm = SetTimer( mHwnd, mTimerSetTmoId, nMillis, nullptr );//WM_TIMER
	return (uint32_t)idtm;
}
HWND TlvTrIcnMgr::pokeLastStaticHwnd( bool bSet, HWND hwNew )
{
	HWND hwOld = mHwnd3;
	if( bSet ){
		mHwnd3 = hwNew;
	}
	return hwOld;
}
void TlvTrIcnMgr::showTrayIcon()
{
	memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
	mNid.cbSize = sizeof(NOTIFYICONDATA);
	mNid.hWnd = mHwnd;
	mNid.uID = 1001;// uId ? ++uId : uId = 1;
	mNid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
	mNid.uCallbackMessage = mWMTrayMessageId;   //WM_USER+0x210
	mNid.hIcon = hxdw_GetWindowIcon( hwManage );
	//GetWindowText( hwManage, mNid.szTip, 128 );
	GetWindowText( hwManage, mNid.szTip, sizeof(mNid.szTip) );
	Shell_NotifyIcon( NIM_ADD, &mNid );
}
bool TlvTrIcnMgr::initInstance( HINSTANCE hInstance, int nCmdShow )
{
	const std::array<int,2> aWHScrn = { GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ),};
	mHwnd = CreateWindow( "Tlv_Helper_Class_C1wXxr", "Tlv_Helper_Class_C1wXxr", WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0,
		int(aWHScrn[0] * 0.4f),
		int(aWHScrn[1] * 0.4f),
		NULL, NULL, NULL, NULL);
	if( !mHwnd ){
		return 0L;
	}
	pokeLastStaticHwnd( 1L, mHwnd );
	SetWindowLongPtr( mHwnd, GWLP_USERDATA, (LONG_PTR)this );
	if( hCloseWith ){
		SetTimer( mHwnd, mTimerClsWthId, mCmdtricn.uWndTimerIntrvl, nullptr );//WM_TIMER
	}
	showTrayIcon();

	if( mCmdtricn.bInitInTray ){
		toggleWindowVisibility( 1L );
	}
	ShowWindow( mHwnd, nCmdShow ); //SW_SHOW
	return 1L;
}
int TlvTrIcnMgr::run2()
{
	registerHlprWndClass( GetModuleHandle(0) );
	bool rs2 = initInstance( GetModuleHandle(0),
			mCmdtricn.bShowHlprWnd ? SW_SHOW : SW_HIDE );
	assert(rs2);
	MSG msg;
	while( GetMessage( &msg, nullptr, 0, 0 ) ){
		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}
	return static_cast<int>( msg.wParam );
}
