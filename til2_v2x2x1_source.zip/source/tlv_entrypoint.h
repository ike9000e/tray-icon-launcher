#pragma once
#include <windows.h>
#include <shellapi.h>   //NOTIFYICONDATA
#include <vector>
#include <string>
#include "detours.h"
#include "hxdw_utils.h"
#include "hxdw_process.h"
#include "hxdw_checksum.h"

struct TlvTrIcnDTO {
	bool bEnabled2 = 0L;  //-T1 -T2 -T3
	bool bCmdFirstParent = 0L;  //-T1
	bool bCmdFirstChild = 0L;   //-T2
	bool bInitInTray = 0L;   //-TI
	int  nTrayminWaitNum = 8;  //-WN; num of times to wait using 'nTrayminIntrvl'.
	int  nTrayminIntrvl = 200;  //-WI; time in millisecs.
	bool bShowHlprWnd = 0L;  //-S1
	uint32_t uWndTimerIntrvl = 2000;  //-M1; time in millisecs.
	bool bUseACStdioEnvVar = 0L;  //-AE1
};

struct TlvUtilMode {
	bool bEnabled3 = 0L;
	bool bGetTimestampSecs = 0L;  //--u_timestamp
	bool bGetTimestampMs = 0L;
	bool bGetTimestampUs = 0L;
	bool bFileMd5 = 0L;
	bool bGetFBinaryType2 = 0L;
	bool bGetFBinaryType3 = 0L;

	std::string srInFile;
};
/// Tray icon manager for single process|window.
struct TlvTrIcnMgr {
	;           TlvTrIcnMgr( HWND hwManage_, HANDLE hCloseWith_, const TlvTrIcnDTO& cmdtricn_ );
	;           ~TlvTrIcnMgr();
	int         run2();
	auto        setTimeout2( uint32_t nMillis, std::function<void(void*user2)> calb2, void* user2 ) -> uint32_t;
	static HWND pokeLastStaticHwnd( bool bSet=0, HWND hwNew=0 ); //mHwnd3
	enum : int{
		mWMTrayMessageId = WM_USER+4136, //WM_USER=1024
		mWMDestroyLv2Id,  //=WM_USER+4137
	};
private:
	friend LRESULT CALLBACK WndProc2( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam );
	auto        WndProc3( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam ) -> LRESULT;
	ATOM        registerHlprWndClass( HINSTANCE hInstance );
	bool        initInstance( HINSTANCE hInstance, int nCmdShow );
	void        showTrayIcon();
	void        toggleWindowVisibility( int nShowInTray );
	friend DWORD WINAPI ThreadProc2( void* param2 );
	void                ThreadProc3();
private:
	static HWND mHwnd3;// = 0;
	//const int mTimerClsWthId = 1001;
	const int mTimerSetTmoId = 1002;
	HWND mHwnd = 0;
	HWND hwManage = 0;
	HANDLE hCloseWith = 0;
	NOTIFYICONDATA mNid;
	bool bIsInTray = 0L;
	TlvTrIcnDTO mCmdtricn;
	std::function<void(void*user2)> mTmoCalb;
	void* mTmoCalbUserVal = 0;
};
template<class Txx>
bool TlvAny( Txx needle2, std::vector<Txx> arr2 )
{
	auto a = std::find( arr2.begin(), arr2.end(), needle2 );
	return a != arr2.end();
}

