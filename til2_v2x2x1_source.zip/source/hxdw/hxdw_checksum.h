#pragma once
#include <string>
#include <vector>
#include <inttypes.h>   //uint32_t

//
// A small class for calculating MD5_ hashes of strings or byte arrays
// it is not meant to be fast or secure
//
// usage:
//      1) feed it blocks of uchars with update2()
//      2) finalize2()
//      3) get getHexDigest() string
//
// assumes that char is 8 bit and int is 32 bit
//
// Class renamed to HxdwMd5, CzmMd5_. Old name MD5.
//
struct HxdwMd5
{
	HxdwMd5();
	HxdwMd5&     update2( const uint8_t* data_, uint32_t length_ );
	HxdwMd5&     finalize2();
	std::string  getHexDigest()const;
	auto         getDigest()const -> std::vector<uint8_t>;
private:
	void update9( const uint8_t *buf, uint32_t length );
	void init2();
	void transform(const uint8_t block[]);
	static void decode(uint32_t output[], const uint8_t input[], uint32_t len);
	static void encode(uint8_t output[], const uint32_t input[], uint32_t len);
	// low level logic operations
	static inline uint32_t F(uint32_t x, uint32_t y, uint32_t z);
	static inline uint32_t G(uint32_t x, uint32_t y, uint32_t z);
	static inline uint32_t H(uint32_t x, uint32_t y, uint32_t z);
	static inline uint32_t I(uint32_t x, uint32_t y, uint32_t z);
	static inline uint32_t rotate_left(uint32_t x, int n);
	static inline void FF(uint32_t &a, uint32_t b, uint32_t c, uint32_t d, uint32_t x, uint32_t s, uint32_t ac);
	static inline void GG(uint32_t &a, uint32_t b, uint32_t c, uint32_t d, uint32_t x, uint32_t s, uint32_t ac);
	static inline void HH(uint32_t &a, uint32_t b, uint32_t c, uint32_t d, uint32_t x, uint32_t s, uint32_t ac);
	static inline void II(uint32_t &a, uint32_t b, uint32_t c, uint32_t d, uint32_t x, uint32_t s, uint32_t ac);
private:
	static_assert( sizeof(int) == 4, "" );
	static_assert( sizeof(char) == 1, "" );
	enum {blocksize = 64,};
	bool bFinalized;
	uint8_t buffer[blocksize]; // bytes that didn't fit in last 64 byte chunk
	uint32_t count[2];   // 64bit counter for number of bits (lo, hi)
	uint32_t state[4];   // digest so far
	uint8_t digest[16]; // the result
};
