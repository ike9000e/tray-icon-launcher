#include "tlv_entrypoint.h"
#include <assert.h>
#include <memory>

const char* szAppName = "TIL2 - Tray Icon Launcher";
const char* szUsage =
		"\n"
		"%s\n"
		"%s\n"
		"\n"
		"    Launches executables and provides the minimize-to-tray functionality.\n"
		"    Meant to be run from batch scripts or from the command prompt.\n"
		"    If no command line program provided, attempts to start a hard-coded\n"
		"    execuatable with the following name: \x22%s\x22.\n"
		"    This is for hex editing (NB. this may've been hexed alrady).\n"
		"\n"
		"    Using '-C1' option may be used to instruct the CMD \n"
		"    to create its own, new command prompt.\n"
		"\n"
		"    https://github.com/ike9000e/tray-icon-launcher\n"
		"\n"
		"    Build: %s, %s-bit\n"
		"\n"
		"Features\n"
		"-----------\n"
		"    * Tray-minimizes window the command creates.\n"
		"    * Tray-minimizes the CMD console. Has options to search \n"
		"      for CMD in the parent or child process list.\n"
		"    * Can attach a DLL library to the starting process.\n"
		"    * Shows icon in the system tray.\n"
		"    * Handles Ctrl+C and auto unhides the window.\n"
		"\n"
		"\n"
		"Usage\n"
		"-------\n"
		"    program.exe [OPTIONS] -- {COMMAND}\n"
		"\n"
		"OPTIONS\n"
		"---------\n"
		"    -T3 - Move to the tray: window that the command creates.\n"
		"    -T2 - Move to the tray: first CMD window from the\n"
		"          child process list.\n"
		"    -T1 - Move to the tray: first CMD window from the\n"
		"          parent process list.\n"
		"    -S1 - Don't hide the helper window that the program \n"
		"          uses inernally. It's created only with \n"
		"          the -T1 -T2 or -T3 option.\n"
		"    -S2 - Show options being used.\n"
		"    -W0 - Don't wait for the command to finish.\n"
		"    -W1 - Wait for the command to finish. The default.\n"
		"    -DL FILE\n"
		"        - Provide a DLL file that is attached|injected to\n"
		"          the created process.\n"
		"    -C1 - Instruct CLI program that it should recieve its \n"
		"          own, new console window. Eg. if the command is CMD,\n"
		"          it starts with the new command prompt.\n"
		"    -TI - Move the window (or command prompt) to the \n"
		"          tray, initially.\n"
		"    -AE1 - Setup an environment variable for further console attach functionality.\n"
		"           Environment variable 'HXDW_PID_STDOUT_7LL55C3O' gets \n"
		"           assigned to the PID of the current process.\n"
		"\n"
		"\n"
		"    Utility Mode Options\n"
		"    ------------------------\n"
		"        In Utility mode the program only performs specified\n"
		"        operation and exits.\n"
		"\n"
		"        --u_timestamp\n"
		"            Returns POSIX timestamp value in seconds. Eg.: 1664630997\n"
		"        --u_timestamp_ms\n"
		"            Same as '--u_timestamp' but in milliseconds.\n"
		"        --u_file_md5 FILE\n"
		"            Calculates MD5 hash|digest for the file.\n"
		"        --u_gbt3 FILE\n"
		"            Get binary type.\n"
		"            Returns binary type of the executable (EXE or DLL), which can be\n"
		"            WIN32(x86), WIN64(x64) or Intel Itanium. Returned value to the\n"
		"            shell - as the errorlevel - is either 32, 64 or 70, respectivelly.\n"
		"\n"
		"\n"
		"Examples\n"
		"----------\n"
		"    program.exe -T2 -W1 -C1 -TI -S1   -- cmd\n"
		"    program.exe -T2 -C1 -WN 8 -WI 200 -- cmd\n"
		"    program.exe -T1 -W1 -C1 -TI -S1   -- calc\n"
		"    program.exe -T1 -C1 -TI -S1       -- mpv.exe m.mkv\n"
		"    program.exe -T3 -S1               -- notepad\n"
		"    program.exe -W0                   -- notepad\n"
		"\n"
		"";
BOOL WINAPI TlvConsoleHandler( DWORD dwSignal )
{
	if( dwSignal == CTRL_C_EVENT ){
		HWND hwnd4 = TlvTrIcnMgr::pokeLastStaticHwnd();
		if( hwnd4 ){
			printf("TLV: Ctrl-C handled.\n");
			PostMessage( hwnd4, TlvTrIcnMgr::mWMDestroyLv2Id, 0, 0 );
			TlvTrIcnMgr::pokeLastStaticHwnd( 1L, 0 );
		}else{
			printf("TLV: Ctrl-C -> process exit.\n");
			return 0L;
		}
		return 1L;
	}
	return 0L;
}
std::string tlv_CalcFileMd5a( std::string fname, const char* flags2 )
{
	bool bShowProgress = !!strchr( flags2, 'p');
	bool bShowIinfo = !!strchr( flags2, 'i');
	if( bShowIinfo ){
		fprintf( stderr, "TLV: calculating MD5...\n");
		fprintf( stderr, "     File: [%s]\n", fname.c_str() );
	}
	uint64_t nReadd = 0u;
	uint64_t fsize = hxdw_GetFileSize2( fname.c_str() );
	if( fsize > 0xFFFFFFFF ){
		return "";//ERROR.
	}
	//const uint32_t uRqBufSize = 65536;
	const uint32_t uRqBufSize = 2*1024*1024;
	HxdwMd5 md5s;
	hxdw_ReadBinaryFileContents(
		fname.c_str(),
		0.f,
		//(uint64_t)2000,
		[&]( const uint8_t* data2, uint32_t len )->bool{
			nReadd += len;
			if( bShowProgress ){
				float perc2 = (fsize ? float(double(nReadd) / fsize) : 0.f);
				fprintf( stderr, "\r%.2f", perc2*100.f );
			}
			md5s.update2( data2, len );
			return 1L;
		}, 0u, uRqBufSize );
	md5s.finalize2();
	if( bShowProgress ){
		fprintf( stderr, "\r%.2f\n", 100.f );
	}
	if( bShowIinfo ){
		fprintf( stderr, "MD5: [%s]\n", md5s.getHexDigest().c_str() );
	}
	return md5s.getHexDigest();
}

/// Returns 1 on success.
/// Exit codes are 160+ if create process failed.
/// \param szCmd - either commandline here, or null - and all commandline
///                is passed via 'argv2' instead.
/// \param argv2 - see 'szCmd'.
bool tlv_ExecProcess( const char* szCmd,
		const std::vector<std::string>& argv2,
		bool bWait, bool bNoWindow, bool bNewConsole,
		int* nExitCode, const char* szDllNameIfAny,
		const TlvTrIcnDTO& sTricn3 )
{
	assert( !szCmd != argv2.empty() );
	std::string cmd2; DWORD exitCode = 0;
	STARTUPINFOA si2;
	PROCESS_INFORMATION pi2;
	ZeroMemory(&si2, sizeof(si2));
	ZeroMemory(&pi2, sizeof(pi2));
	si2.cb = sizeof(si2);
	if( !argv2.empty() ){
		for( auto a : argv2 ){
			a = ( !!strchr( a.c_str(), '\x20' ) ? ("\x22"+a+"\x22") : a );
			cmd2 += a + "\x20";
		}
	}else{
		cmd2 = szCmd;
	}
	std::shared_ptr<int> raii2( 0, [&]( int* ){
		if( pi2.hProcess ){ CloseHandle( pi2.hProcess ); pi2.hProcess = 0;}
		if( pi2.hThread ){  CloseHandle( pi2.hThread  ); pi2.hThread  = 0;}
		if( nExitCode ){ *nExitCode = (int)exitCode; }
	});
	//printf("TLV: Command-line: [%s]\n", cmd2.c_str() );

	// REF:
	// * CreateProcessA()
	//   https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessa
	// * Process Creation Flags
	//   https://learn.microsoft.com/en-us/windows/win32/procthread/process-creation-flags
	// dwCreationFlags:
	//     CREATE_NO_WINDOW(0x08000000): dont spawn the console for CLI programs.
	//         - this affects CLI processes, fe. the cmd.exe itself.
	//     CREATE_NEW_CONSOLE(0x00000010): affects CLI programs, fe. CMD.
	//         - without it, CMD runs in current window,
	//           ie. doesnt create it's own.

	//DetourCreateProcessWithDllEx()
	szDllNameIfAny = ( szDllNameIfAny && *szDllNameIfAny ? szDllNameIfAny : nullptr );

	//printf("TLV: Setting up STD handles.\n", 0 );
	si2.dwFlags |= STARTF_USESTDHANDLES;
	si2.hStdInput  = GetStdHandle( STD_INPUT_HANDLE );
	si2.hStdOutput = GetStdHandle( STD_OUTPUT_HANDLE );
	si2.hStdError  = GetStdHandle( STD_ERROR_HANDLE );

	if( sTricn3.bUseACStdioEnvVar ){//-AE1
		// For future use with hxdw_AttachConsoleEnvIf2() in child processes.
		SetEnvironmentVariable("HXDW_PID_STDOUT_7LL55C3O",
			hxdw_StrPrintf("%d,", { (int64_t) GetCurrentProcessId(),}).c_str() );
	}
	bool rs2 = DetourCreateProcessWithDlls(
			nullptr, (char*)cmd2.c_str(),   //lpCommandLine
			nullptr, nullptr,
			1L,            //bInheritHandles,
			(bNewConsole ? CREATE_NEW_CONSOLE : 0) |
				(bNoWindow ? CREATE_NO_WINDOW : 0),  //dwCreationFlags
			nullptr, nullptr,
			&si2, &pi2,
			(szDllNameIfAny ? 1 : 0),
			(szDllNameIfAny ? &szDllNameIfAny : nullptr),
			CreateProcess );
	if( !rs2 ){
		std::string err2 = hxdw_GetLastError();
		printf("TLV: ERROR: failed creating new process [dJ05ZT]\n");
		printf("     Command: [%s]\n", cmd2.c_str() );
		printf("     Message: [%s]\n", err2.c_str() );
		exitCode = 160;
		return 0L;
	}
	assert( pi2.dwThreadId );
	assert( pi2.dwProcessId );
	if( sTricn3.bEnabled2 ){
		if( sTricn3.bCmdFirstParent ){
			HWND hw2 = (HWND)hxdw_FindParentCMDWindow( 0, nullptr, "o");
			assert( hw2 );
			TlvTrIcnMgr ti2( hw2, pi2.hProcess, sTricn3 );
			ti2.run2();
		}else if( sTricn3.bCmdFirstChild ){
			HWND hw3 = 0;
			DWORD pid3 = GetCurrentProcessId();
			for( int ii2=0; ii2 < sTricn3.nTrayminWaitNum; ii2++ ){
				if( (hw3 = (HWND)hxdw_FindChildCMDWindow( pid3, nullptr, "o" )) )
					break;
				printf("TLV: waiting2...\n");
				Sleep( sTricn3.nTrayminIntrvl );
			}
			assert( hw3 );
			TlvTrIcnMgr ti3( hw3, pi2.hProcess, sTricn3 );
			ti3.run2();
		}else{   //else regular process wait.
			HWND hwProc = 0;
			for( int ii2=0; ii2 < sTricn3.nTrayminWaitNum; ii2++ ){
				if( (hwProc = hxdw_FindMainWindowGivenPID( pi2.dwProcessId, "" )) )
					break;
				printf("TLV: waiting3...\n");
				Sleep( sTricn3.nTrayminIntrvl );
			}
			if( hwProc ){
				std::string sr2 = hxdw_GetWindowText( hwProc );
				printf("TLV: PID:%d, wnd: [%s]\n", (int)pi2.dwProcessId, sr2.c_str() );
				TlvTrIcnMgr ti4( hwProc, pi2.hProcess, sTricn3 );
				ti4.run2();
			}else{
				printf("TLV: ERROR: failed finding any window for PID:%d\n", (int)pi2.dwProcessId );
			}
		}
	}
	if( !bWait ){
		return 1L; //ok.
	}
	if( WAIT_FAILED == WaitForSingleObject( pi2.hProcess, INFINITE ) ){
		printf("TLV: ERROR: failed waiting for process to finish [3oXV6H]\n");
		exitCode = 161;
		return 0L;
	}
	bool rs3 = !!GetExitCodeProcess( pi2.hProcess, &exitCode );
	if(!rs3){ // if no exit code.
		printf("TLV: ERROR: failed getting process exit code [j8hHgl]\n");
		exitCode = 163;
		return 0L;
	}
	return 1L; //ok.
}
int main( int argc, const char*const* argv )
{
	std::string exec2, srDllNme2;
	const char* szHardExecName = "run_me_no_parameters.exe\0;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;";
	bool bWait = 1L, bFoundDblDash = 0L, bNoWindow = 0L;
	bool bNewConsole = 0L, bShowOptions = 0L, bHlp = 0L;
	TlvTrIcnDTO sTricn2;
	TlvUtilMode sUtil;
	for( int ii2=1; ii2<argc; ii2++ ){
		bool bHlp2 = (
			!lstrcmpi( argv[ii2], "-h" ) || !lstrcmpi( argv[ii2], "-help" ) ||
			!lstrcmpi( argv[ii2], "--h" ) || !lstrcmpi( argv[ii2], "--help" ) ||
			!lstrcmpi( argv[ii2], "-?" ) || !lstrcmpi( argv[ii2], "/?" ) );
		if( bHlp2 ){
			bHlp = 1L;
			break;
		}
		if( bFoundDblDash ){
			const char* argx = argv[ii2];
			if( *argx ){
				exec2 += ( !exec2.empty() ? " " : "" );
				if( std::strchr( argx, '\x20' ) ){
					exec2 += ( std::string("\x22") + std::string(argx) + "\x22");
				}else{
					exec2 += argx;
				}
			}
			continue;
		}
		if(0){
		}else if( !lstrcmpi( argv[ii2], "--bWait") || !strcmp( argv[ii2], "-W1") ){
			bWait = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bNoWait") || !strcmp( argv[ii2], "-W0") ){
			bWait = 0L;
		}else if( !lstrcmpi( argv[ii2], "--bNoWindow") || !strcmp( argv[ii2], "-N") ){
			bNoWindow = 1L;
		}else if( !lstrcmpi( argv[ii2], "--Dll2") || !strcmp( argv[ii2], "-DL") ){
			srDllNme2 = (ii2+1 < argc ? argv[ii2+1] : "");
		}else if( !lstrcmpi( argv[ii2], "--bInitInTray") || !strcmp( argv[ii2], "-TI") ){
			sTricn2.bInitInTray = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bNewConsole") || !strcmp( argv[ii2], "-C1") ){
			bNewConsole = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bShowHlprWnd") || !strcmp( argv[ii2], "-S1") ){
			sTricn2.bShowHlprWnd = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bCMDTrIcnP") || !strcmp( argv[ii2], "-T1") ){
			sTricn2.bEnabled2 = 1L;
			sTricn2.bCmdFirstParent = 1L;
			sTricn2.bCmdFirstChild = 0L;
		}else if( !lstrcmpi( argv[ii2], "--bCMDTrIcnC") || !strcmp( argv[ii2], "-T2") ){
			sTricn2.bEnabled2 = 1L;
			sTricn2.bCmdFirstParent = 0L;
			sTricn2.bCmdFirstChild = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bTrIcnA") || !strcmp( argv[ii2], "-T3") ){
			sTricn2.bEnabled2 = 1L;
		}else if( !lstrcmpi( argv[ii2], "--bShowOptions") || !strcmp( argv[ii2], "-S2") ){
			bShowOptions = 1L;
		}else if( !strcmp( argv[ii2], "--") ){
			bFoundDblDash = 1L;
		}else if( !lstrcmpi( argv[ii2], "--nTrayminWaitNum") || !strcmp( argv[ii2], "-WN") ){
			sTricn2.nTrayminWaitNum = ( ii2+1 < argc ? atoi( argv[ii2+1] ) : sTricn2.nTrayminWaitNum );
		}else if( !lstrcmpi( argv[ii2], "--nTrayminIntrvl") || !strcmp( argv[ii2], "-WI") ){
			sTricn2.nTrayminIntrvl = ( ii2+1 < argc ? atoi( argv[ii2+1] ) : sTricn2.nTrayminIntrvl );
		}else if( !lstrcmpi( argv[ii2], "--uWndTimerIntrvl") || !strcmp( argv[ii2], "-M1") ){
			sTricn2.uWndTimerIntrvl = ( ii2+1 < argc ? atoi( argv[ii2+1] ) : sTricn2.uWndTimerIntrvl );
		}else if( !lstrcmpi( argv[ii2], "--u_timestamp") ){
			sUtil.bGetTimestampSecs = sUtil.bEnabled3 = 1L;
		}else if( !lstrcmpi( argv[ii2], "--u_timestamp_ms") ){
			sUtil.bGetTimestampMs = sUtil.bEnabled3 = 1L;
		}else if( !lstrcmpi( argv[ii2], "--u_timestamp_us") ){
			sUtil.bGetTimestampUs = sUtil.bEnabled3 = 1L;
		}else if( !lstrcmpi( argv[ii2], "--u_file_md5") ){
			sUtil.bFileMd5 = sUtil.bEnabled3 = 1L;
			sUtil.srInFile = (ii2+1 < argc ? argv[ii2+1] : "");
		}else if( !lstrcmpi( argv[ii2], "--u_gbt2") ){
			sUtil.bGetFBinaryType2 = sUtil.bEnabled3 = 1L;
			sUtil.srInFile = (ii2+1 < argc ? argv[ii2+1] : "");
		}else if( !lstrcmpi( argv[ii2], "--u_gbt3") ){
			sUtil.bGetFBinaryType3 = sUtil.bEnabled3 = 1L;
			sUtil.srInFile = (ii2+1 < argc ? argv[ii2+1] : "");
		}else if( !lstrcmpi( argv[ii2], "--bUseACStdioEnvVar") || !strcmp( argv[ii2], "-AE1") ){
			sTricn2.bUseACStdioEnvVar = 1;
		}
	}
	if( bHlp || argc <= 1 ){
		std::string srRuller, srDate;
		srRuller.resize( (size_t)strlen( szAppName )+2, '-');
		char bfrArchitecture[128] = {0,};
		snprintf( bfrArchitecture, sizeof(bfrArchitecture), "%d", (int)(sizeof(size_t)*8) );
		srDate = hxdw_GetDateAtCompileTime(""); //__DATE__ replacement.
		printf( szUsage, szAppName, srRuller.c_str(), szHardExecName, srDate.c_str(), bfrArchitecture );
		return 10;
	}
	if( sUtil.bEnabled3 ){
		uint64_t tms2 = 0;
		if(0){
		}else if( sUtil.bGetTimestampSecs ){  //--u_timestamp
			tms2 = hxdw_GetPosixTimeUs() / (1000u*1000u);
		}else if( sUtil.bGetTimestampMs ){  //--u_timestamp_ms
			tms2 = hxdw_GetPosixTimeUs() / 1000u;
		}else if( sUtil.bGetTimestampUs ){  //--u_timestamp_us
			tms2 = hxdw_GetPosixTimeUs();
		}else if( sUtil.bFileMd5 ){  //--u_file_md5
			std::string md5x = tlv_CalcFileMd5a( sUtil.srInFile.c_str(), "ip");
			printf("%s\n", md5x.c_str() );
			return ( md5x.empty() ? 1 : 0 );
		}else if( sUtil.bGetFBinaryType2 ){  //--u_gbt2
			const DWORD type2 = hxdw_GetBinaryType( sUtil.srInFile.c_str() );
			const int type3 = ( type2 == SCS_32BIT_BINARY ? 32 : ( type2 == SCS_64BIT_BINARY  ? 64 : 1 ));
			printf("%d\n", type3 );
			return ( type3 != 1 ? type3 : 1 );
		}else if( sUtil.bGetFBinaryType3 ){  //--u_gbt3
			int32_t type4 = hxdw_GetBinaryType3( sUtil.srInFile.c_str(), "" );
			printf("%d\n", (int)type4 );
			return ( type4 ? type4 : 1 );
		}else{
			assert(!"Unexpected branch reached [JxA46Ry]");
		}
		if(tms2){
			printf("%s\n", std::to_string(tms2).c_str() );
		}
		return 0;  //0: shell-ok
	}
	//printf("TLV: Arch: %s\n",  );
	if( bShowOptions ){
		printf("TLV: Configuration:\n");
		printf("    bWait             : %d\n", (int)bWait );
		printf("    bNoWindow         : %d\n", (int)bNoWindow );
		printf("    bNewConsole       : %d\n", (int)bNewConsole );
		printf("    C.bEnabled2       : %d\n", (int)sTricn2.bEnabled2 );
		printf("    C.bCmdFirstParent : %d\n", (int)sTricn2.bCmdFirstParent );
		printf("    C.bCmdFirstChild  : %d\n", (int)sTricn2.bCmdFirstChild );
		printf("    C.bInitInTray     : %d\n", (int)sTricn2.bInitInTray );
		printf("    C.nTrayminWaitNum : %d\n", (int)sTricn2.nTrayminWaitNum );
		printf("    C.nTrayminIntrvl  : %d\n", (int)sTricn2.nTrayminIntrvl );
		printf("    C.bShowHlprWnd    : %d\n", (int)sTricn2.bShowHlprWnd );
	}
	if( exec2.empty() ){
		exec2 = szHardExecName;
	}
	if( !SetConsoleCtrlHandler( TlvConsoleHandler, 1L ) ){
		printf("TLV: ERROR: Could not set control handler [McGYEo]\n");
		return 151;
	}
	int nExitCode2 = 255;
	if( !tlv_ExecProcess( exec2.c_str(), {}, bWait, bNoWindow,
			bNewConsole, &nExitCode2, srDllNme2.c_str(),
			sTricn2 ) ){
		return nExitCode2;
	}
	if( bWait ){
		return nExitCode2;
	}
	return 0;
}

TlvTrIcnMgr::TlvTrIcnMgr( HWND hwManage_, HANDLE hCloseWith_, const TlvTrIcnDTO& cmdtricn_ )
	: hCloseWith(hCloseWith_)
	, hwManage(hwManage_)
	, mCmdtricn(cmdtricn_)
{
	memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
}
HWND TlvTrIcnMgr::mHwnd3 = 0;
TlvTrIcnMgr::~TlvTrIcnMgr()
{
	if( hwManage && bIsInTray ){
		toggleWindowVisibility( 0L );
	}
	if( mNid.hWnd ){
		Shell_NotifyIcon( NIM_DELETE, &mNid );
		memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
	}
}
void TlvTrIcnMgr::toggleWindowVisibility( int nShowInTray )
{
	assert( hwManage );
	if( nShowInTray == -1 ){
		nShowInTray = !!IsWindowVisible(hwManage);
	}
	if( nShowInTray ){
		ShowWindow(hwManage, SW_HIDE);//SW_MINIMIZE
		bIsInTray = 1L;
	}else{
		ShowWindow(hwManage, SW_SHOW);
		ShowWindow(hwManage, SW_RESTORE);
		SetForegroundWindow(hwManage);
		bIsInTray = 0L;
	}
}
LRESULT CALLBACK
WndProc2( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
	TlvTrIcnMgr* this2 = (TlvTrIcnMgr*)GetWindowLongPtr( hWnd, GWLP_USERDATA );
	if(this2){
		return this2->WndProc3( hWnd, message, wParam, lParam );
	}
	return DefWindowProc( hWnd, message, wParam, lParam );
}
LRESULT TlvTrIcnMgr::WndProc3( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
	if( message == mWMTrayMessageId ){
		if( TlvAny<int>( lParam, {WM_LBUTTONDOWN,WM_LBUTTONDBLCLK,} ) ){
			toggleWindowVisibility( -1 );
		}
	}else if( message == TlvTrIcnMgr::mWMDestroyLv2Id ){
		DestroyWindow(hWnd);
	}
	switch(message){
	case WM_COMMAND:{
			int wmId = LOWORD(wParam);
			int wmEvent = HIWORD(wParam);
			switch( wmId ){
			default:
				return DefWindowProc( hWnd, message, wParam, lParam );
			}
		}
		break;
	case WM_DESTROY:
		printf("TLV: Processing WM_DESTROY\n");
		PostQuitMessage(0);
		return 1L;
	case WM_KEYDOWN:{
			int nVirtKey = (int) wParam;    // virtual-key code
			if( nVirtKey == 'Q' ){
				// Ctrl+Q to quit, implementation.
				if( GetAsyncKeyState(VK_CONTROL) & 0x8000 ){
					DestroyWindow(hWnd);
				}
			}else if( nVirtKey == 'T' ){
				printf("T\n");
				this->setTimeout2( 1200, [](void*user2){
                    printf("T2, %d\n", (int)(size_t)user2 );
				}, (void*)42 );
			}
		}
		break;
	case WM_TIMER:{
			int nTimerID = wParam;
			if(0){
		//	}else if( nTimerID == mTimerClsWthId ){
		//		if( hCloseWith ){
		//			//printf("WM_TIMER_\n");
		//			if( WAIT_OBJECT_0 == WaitForSingleObject( hCloseWith, 0 ) ){
		//				DestroyWindow(hWnd);
		//			}
		//		}
			}else if( nTimerID == mTimerSetTmoId ){
				KillTimer( hWnd, mTimerSetTmoId );
				mTmoCalb( mTmoCalbUserVal );
			}
		}
		break;
	default:
		return DefWindowProc( hWnd, message, wParam, lParam );
	}
	return 0;
}
ATOM TlvTrIcnMgr::registerHlprWndClass( HINSTANCE hInstance )
{
	WNDCLASSEX wcex;
	memset( &wcex, 0, sizeof(wcex) );
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc2; //(WNDPROC)
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wcex.lpszMenuName = "Tlv_Helper_Class_C1wXxr";
	wcex.lpszClassName = "Tlv_Helper_Class_C1wXxr";
	//wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));
	return RegisterClassEx(&wcex);
}
/// Returns 0 on error.
uint32_t TlvTrIcnMgr::
setTimeout2( uint32_t nMillis, std::function<void(void*user2)> calb2, void* user2 )
{
	assert( !!calb2 );
	mTmoCalb = calb2;
	mTmoCalbUserVal = user2;

	assert( mHwnd );
	UINT idtm = SetTimer( mHwnd, mTimerSetTmoId, nMillis, nullptr );//WM_TIMER
	return (uint32_t)idtm;
}
HWND TlvTrIcnMgr::pokeLastStaticHwnd( bool bSet, HWND hwNew )
{
	HWND hwOld = mHwnd3;
	if( bSet ){
		mHwnd3 = hwNew;
	}
	return hwOld;
}
void TlvTrIcnMgr::showTrayIcon()
{
	memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
	mNid.cbSize = sizeof(NOTIFYICONDATA);
	mNid.hWnd = mHwnd;
	mNid.uID = 1001;// uId ? ++uId : uId = 1;
	mNid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
	mNid.uCallbackMessage = mWMTrayMessageId;   //WM_USER+0x210
	mNid.hIcon = hxdw_GetWindowIcon( hwManage );
	//GetWindowText( hwManage, mNid.szTip, 128 );
	GetWindowText( hwManage, mNid.szTip, sizeof(mNid.szTip) );
	Shell_NotifyIcon( NIM_ADD, &mNid );
}
DWORD WINAPI ThreadProc2( void* param2 )
{
	TlvTrIcnMgr* this2 = (TlvTrIcnMgr*)param2;
	assert(this2);
	this2->ThreadProc3();
	return 0;
}
void TlvTrIcnMgr::ThreadProc3()
{
	assert( hCloseWith );
	if( WAIT_FAILED != WaitForSingleObject( hCloseWith, INFINITE ) ){
		printf("TLV: Helper thread: handle close detected [fmOwOzY]\n");
		PostMessage( mHwnd, TlvTrIcnMgr::mWMDestroyLv2Id, 0, 0 );
	}else{
		printf("TLV: ERROR: Helper thread: failed waiting for handle close [xSAAiPk]\n");
	}
}
bool TlvTrIcnMgr::initInstance( HINSTANCE hInstance, int nCmdShow )
{
	const std::array<int,2> aWHScrn = { GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ),};
	mHwnd = CreateWindow( "Tlv_Helper_Class_C1wXxr", "Tlv_Helper_Class_C1wXxr", WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0,
		int(aWHScrn[0] * 0.4f),
		int(aWHScrn[1] * 0.4f),
		NULL, NULL, NULL, NULL);
	if( !mHwnd ){
		return 0L;
	}
	pokeLastStaticHwnd( 1L, mHwnd );
	SetWindowLongPtr( mHwnd, GWLP_USERDATA, (LONG_PTR)this );
	if( hCloseWith ){
		//SetTimer( mHwnd, mTimerClsWthId, mCmdtricn.uWndTimerIntrvl, nullptr );//WM_TIMER

		CreateThread( nullptr, 0, ThreadProc2, this, 0, nullptr );
	}
	showTrayIcon();
	if( mCmdtricn.bInitInTray ){
		toggleWindowVisibility( 1L );
	}
	ShowWindow( mHwnd, nCmdShow ); //SW_SHOW
	return 1L;
}
int TlvTrIcnMgr::run2()
{
	registerHlprWndClass( GetModuleHandle(0) );
	bool rs2 = initInstance( GetModuleHandle(0),
			mCmdtricn.bShowHlprWnd ? SW_SHOW : SW_HIDE );
	assert(rs2);
	MSG msg;
	while( GetMessage( &msg, nullptr, 0, 0 ) ){
		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}
	return static_cast<int>( msg.wParam );
}
