
#include "hxdw_process.h"
#include <cstring>
#include <assert.h>
#include <assert.h>
#ifdef _MSC_VER
	#pragma warning( disable: 4091 ) // Win SDK 7.1 | 'typedef ': ignored on left of '<unnamed-enum-sfImage>' when no variable is declared|
#endif
#include <windows.h>
#include <tlhelp32.h>  //CreateToolhelp32Snapshot(), PROCESSENTRY32
#include <psapi.h>     //EnumProcessModules() -> psapi.lib
#include <dbghelp.h>   //ImageNtHeader() -> dbghelp.lib.
#include "hxdw_utils.h"

/// Check if a process is running
/// \param processName - Name of process to check if it is running.
/// Returns True if the process is running.
/// https://stackoverflow.com/a/14751302
bool hxdw_IsExistingProcess( uint32_t pid_ )
{
	const DWORD pid2 = static_cast<DWORD>( pid_ );
	bool bExists = 0L;
	hxdw_EnumerateSystemProcesses( [&]( const PROCESSENTRY32& en2 ){
		//en2.th32ParentProcessID//en2.szExeFile
		if( en2.th32ProcessID == pid2 ){
			bExists = 1L;
			return 0L;
		}
		return 1L;
	});
	return bExists;
}
/// Returns module base address - the image base.
/// For example, can be used with offsets of compiled values.
/// Offsets can be obtained from eg. Cheat Engine.
/// Can be used inside DLLs or EXEs.
/// \param procId - process id, pid. Eg. use GetCurrentProcessId().
///                 If zero, it is the current process.
///                 If both parameters, 'procId' and 'szModName' are null, more reliable method is used.
/// \param szModName - module name of DLL or EXE, eg. "Notepad.exe". Base name - no path part.
///                    if zero, retrieves for the first EXE.
/// ref: https://stackoverflow.com/questions/46821118/c-c-how-can-i-get-base-address-of-exe-running-process
size_t hxdw_GetModuleBaseAddress( uint32_t procId, const char* szModName )
{
	size_t uModBaseAddr = 0;
	const bool bGetForExe = ( !szModName || !(*szModName) );
	const bool bGetForCurrProc = ( !procId && bGetForExe ? 1 : 0 );
	procId = ( procId ? procId : GetCurrentProcessId() );
	if( bGetForCurrProc ){
		// if for current process, use more reliable method
		// by not using tool-snapshot utility.
		HMODULE hModule = 0;
		hxdw_EnumerateProcessModules( procId, [&](const HxdwModOnEnum& inp)->bool{
				std::string ext2 = hxdw_SplitExt( inp.srPath.c_str() ).second;
				if( !lstrcmpi( ext2.c_str(), "exe") ){
					hModule = (HMODULE)inp.hDll;
					return 0;
				}
				return 1;
			});
		if( hModule ){
			// include psapi.h, link to psapi.lib
			// https://stackoverflow.com/a/15200993
			MODULEINFO mii;
			std::memset( &mii, 0, sizeof(mii) );
			bool rs2 = !!GetModuleInformation( GetCurrentProcess(), hModule, &mii, sizeof(mii) );
			if( rs2 ){
				size_t uModBaseAddr2 = (size_t)mii.lpBaseOfDll;
				return uModBaseAddr2;
			}
		}
		return 0;
	}
	HANDLE hSnap = CreateToolhelp32Snapshot( TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, procId );
	if( hSnap != INVALID_HANDLE_VALUE ){
		MODULEENTRY32 aModEntry;
		aModEntry.dwSize = sizeof(aModEntry);
		for( bool rs2 = !!Module32First( hSnap, &aModEntry ); rs2; rs2 = !!Module32Next( hSnap, &aModEntry ) ){
			if( bGetForExe ){
				std::string ext2 = hxdw_SplitExt(aModEntry.szModule).second;
				//if( !hxdw_StrCmpOpt( ext2.c_str(), "exe", -1, "i") ){}
				if( !lstrcmpi( ext2.c_str(), "exe") ){
					uModBaseAddr = (size_t)aModEntry.modBaseAddr;
					break;
				}
			}else{
				assert(szModName);
				if( !lstrcmpi( aModEntry.szModule, szModName ) ){
					uModBaseAddr = (size_t)aModEntry.modBaseAddr;
					break;
				}
			}
		}
		CloseHandle( hSnap );
	}
	return uModBaseAddr;
}
/*
// Normalizes the path returned by GetProcessImageFileName
// https://social.msdn.microsoft.com/Forums/en-US/c48bcfb3-5326-479b-8c95-81dc742292ab/windows-api-to-get-a-full-process-path?forum=vcgeneral
HRESULT __NormalizeNTPath( wchar_t* pszPath, size_t nMax )
{
	wchar_t* pszSlash = wcschr(&pszPath[1], '\\');
	if (pszSlash) pszSlash = wcschr(pszSlash+1, '\\');
	if (!pszSlash)
		return E_FAIL;
	wchar_t cSave = *pszSlash;
	*pszSlash = 0;

	wchar_t szNTPath[_MAX_PATH];
	wchar_t szDrive[_MAX_PATH] = L"A:";
	// We'll need to query the NT device names for the drives to find a match with pszPath
	for (wchar_t cDrive = 'A'; cDrive <= 'Z'; ++cDrive)
	{
		#define NUMCHARS(arr) sizeof(arr) / sizeof(arr[0])
		szDrive[0] = cDrive;
		szNTPath[0] = 0;
		if( QueryDosDeviceW( szDrive, szNTPath, NUMCHARS(szNTPath)) &&
			!_wcsicmp(szNTPath, pszPath) )
		{
			// Match
			wcscat_s(szDrive, NUMCHARS(szDrive), L"\\" );
			wcscat_s(szDrive, NUMCHARS(szDrive), pszSlash+1);
			wcscpy_s(pszPath, nMax, szDrive);
			return S_OK;
		}
		#undef NUMCHARS
	}
	*pszSlash = cSave;
	return E_FAIL;
}//*/

bool hxdw_EnumerateProcessModules( uint32_t pid2, std::function<bool(const HxdwModOnEnum&)> calb2 )
{
	HMODULE hMods[1024] = {0,};
	HANDLE hProcess;
	DWORD cbNeeded, processID = static_cast<DWORD>( pid2 );
	processID = (processID ? processID : GetCurrentProcessId());
	//
	hProcess = OpenProcess( PROCESS_QUERY_INFORMATION |
							PROCESS_VM_READ,
							FALSE, processID );
	if( !hProcess ){
		return 0;
	}
	// Get a list of all the modules in this process.
	if( EnumProcessModules( hProcess, hMods, sizeof(hMods), &cbNeeded ) ){
		unsigned int ii2;
		for( ii2 = 0; ii2 < ( cbNeeded / sizeof(HMODULE) ); ii2++ ){
			char szModName[MAX_PATH];
			bool rs2 = !!GetModuleFileNameEx( hProcess, hMods[ii2], szModName, sizeof(szModName) );
			//
			// Errors in GetModuleFileNameEx().
			// - errors when called from a 32bit environemet to get to 64bit process.
			// https://stackoverflow.com/a/13997349
			// GetProcessImageFileNameA, GetProcessImageFileName, QueryDosDevice
			// // NormalizeNTPath():
			// // ref: https://social.msdn.microsoft.com/Forums/en-US/c48bcfb3-5326-479b-8c95-81dc742292ab/windows-api-to-get-a-full-process-path?forum=vcgeneral
			//
			if( rs2 ){
				HxdwModOnEnum moe = { hMods[ii2], szModName,};
				if( !calb2( moe ) ){
					break;
				}
			}
		}
	}
	// Release the handle to the process.
	CloseHandle( hProcess );
	return 1;
}

/// Gets modules given pid.
/// BUG: errors in win32, not in win64.
/// - errors when called from a 32bit environemet to get to 64bit process.
std::string hxdw_GetProcessBinaryPath( uint32_t pid2 )
{
	HANDLE hProcess = 0;
	std::shared_ptr<void> raii2( 0, [&]( void* ){
		if( hProcess ){
			CloseHandle( hProcess );
			hProcess = 0;
		}
	});
	hProcess = OpenProcess( PROCESS_QUERY_INFORMATION|PROCESS_VM_READ,
							FALSE, (DWORD)pid2 );
	if( !hProcess ){
		return "";
	}
	char bfr2[MAX_PATH] = "";
	GetProcessImageFileName( hProcess, bfr2, sizeof(bfr2) ); //psapi.h
	// returns dos path, rather than drive letter path, eg. "\Device\Harddisk0\Partition1\Windows\System32\abc.exe"
	//__NormalizeNTPath
	std::string outp2 = hxdw_NormalizeNTPath( bfr2 );
	return outp2;

/*	std::string outp;
	hxdw_EnumerateProcessModules( pid2, [&](const HxdwModOnEnum& inp)->bool{
		std::string ext2;
		ext2 = hxdw_SplitExt( hxdw_SplitPath( inp.srPath ).second ).second;
		if( !hxdw_StrCmpOpt( ext2.c_str(), "exe", -1, "i") ){
			outp = inp.srPath.c_str();
			return 0;
		}
		return 1;
	});
	return outp;
	//*/
}


/**
	Enumerates module sections.
	\param hMod - module handle.
		\code
			// Examples:
			HMODULE hMod = GetModuleHandleA("kernelbase.dll");
			HMODULE hMod = GetModuleHandleA("calc.exe");
		\endcode
	Ref:
	https://reverseengineering.stackexchange.com/a/22140
	https://docs.microsoft.com/en-us/windows/win32/api/dbghelp/nf-dbghelp-imagentheader
	https://docs.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-image_nt_headers32
	https://docs.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-image_section_header

	Example:
		======================================
		Name            VA      Raw     Size
		======================================
		.text           1000    400     102600
		.rdata          104000  102a00  155e00
		.data           25a000  258800  1600
		.pdata          25f000  259e00  e800
		.didat          26e000  268600  800
		.rsrc           26f000  268e00  600
		.reloc          270000  269400  22400
*/
bool hxdw_EnumerateModuleSections(
		void* hMod, //HMODULE
		std::function<bool( const HxdwMSectEnum& inp )> calb2 )
{
	hMod = ( hMod ? hMod : GetModuleHandleA( nullptr ) );
	if( !hMod ){
		return 0;
	}
	//#ifdef _WIN64
	//	PIMAGE_NT_HEADERS64 NtHeader = ImageNtHeader(hMod);
	//#else
	//	PIMAGE_NT_HEADERS32 NtHeader = ImageNtHeader(hMod);
	//#endif
	PIMAGE_NT_HEADERS NtHeader = ImageNtHeader( hMod );
	WORD NumSections = NtHeader->FileHeader.NumberOfSections;
	PIMAGE_SECTION_HEADER section2 = IMAGE_FIRST_SECTION(NtHeader);
	//DWORD old_protect;
	//VirtualProtect( section2, 2, PAGE_READONLY, &old_protect );
	for( WORD i = 0; i < NumSections; i++ ){
		//char bfr2[256];
		//snprintf( bfr2, sizeof(bfr2),
		//		"%-8s\t%x\t%x\t%x",
		//			section2->Name,
		//			section2->VirtualAddress,
		//			section2->PointerToRawData,
		//			section2->SizeOfRawData );
		char bfrName[IMAGE_SIZEOF_SHORT_NAME+1] = "";
		std::memset( bfrName, 0, sizeof(bfrName) );
		std::memcpy( bfrName, section2->Name, IMAGE_SIZEOF_SHORT_NAME );
		const HxdwMSectEnum sMSec = {
				bfrName,
				section2->VirtualAddress,
				section2->PointerToRawData,
				section2->SizeOfRawData, };
		if( !calb2( sMSec ) ){
			break;
		}
		section2++;
	}
	return 1;
}
/**
	Retrieves address (aka. offset aka. VA) of the section (aka. segment) of the module.
	Address also known as offset or virtual address or VA.
	Section also known as segment.

	Returned is the virtual address.
	Eg. the well known section name of the code section is ".text".
	Passing NULL as 'hMod' auto reitrieves the address of the main
	module, executable, the ".exe" (ie. not any of the DLLs).

	\verbatim
		=======================================
		| Name     VA      Raw     Size
		=======================================
		[.text     1000    400     706200]
		[PSFD00    708000  706600  3600]
		[.rdata    70c000  709c00  e6a00]
		[.data     7f3000  7f0600  58a00]
		[.idata    1310000 849000  2000]
		[.rsrc     1312000 84b000  2800]
		[.reloc    1315000 84d800  67600]
	\endverbatim

	Code section address is usefull for patching opcodes
	inside the running executable.
	When using debugger, like IDA, after obtaining an offset inside the
	code section, it then must must be added to both, the image base and
	the section address.

	\param hMod - Handle of a module (HMODULE). If NULL, defaults to the main executable one.
	\param szSecName - section name, eg. ".text". If NULL defaults to ".text".
	\return Code section address or NULL on error.

	// VirtualAddress:
	//     The address of the first byte of the section when loaded into
	//     memory, relative to the image base. For object files, this is
	//     the address of the first byte before relocation is applied.

	\code
		// Example
		size_t addrExeBase     = hxdw_GetModuleBaseAddress(0,"");
		size_t addrCodeSection = hxdw_GetModuleSectionVAddress(0,".text");
		size_t addr_to_patch   = addrExeBase + addrCodeSection + 0xADD8E5;
		std::memcpy( (void*)addr_to_patch, pNewBytes, 5 );
	\endcode
*/
size_t hxdw_GetModuleSectionVAddress( void* hMod, const char* szSecName )
{
	hMod = ( hMod ? hMod : GetModuleHandle( nullptr ) );
	szSecName = ( szSecName ? szSecName : ".text" );
	size_t rslt = 0;
	hxdw_EnumerateModuleSections( hMod, [&]( const HxdwMSectEnum& inp )->bool{
		if( !hxdw_StrCmpOpt( szSecName, inp.szName, -1, "i") ){
			rslt = (size_t)inp.uVirtualAddress;
			return 0;  //0: finish-enumeration.
		}
		return 1;
	} );
	return rslt;
}
/*
	Returns pointer that can be used with memcpy style calls.

	uPID - can be zero. zero defaults to the current process.
	szModName - can be null. null defaults to the main executable (.exe) one.
	szSecName - can be null. null defaults to ".text" - the code section.
	uInSectionOffset - offset in the section, from the section begin.
*/
void* hxdw_GetPtrGivenInSectionOffset(
			uint32_t uPID, const char* szModName,
			const char* szSecName, size_t uInSectionOffset )
{
	szModName = ( szModName && *szModName ? szModName : nullptr );
	void* hMod = GetModuleHandle( szModName );
	if( hMod ){
		size_t addrExeBase = hxdw_GetModuleBaseAddress( uPID, szModName );
		if( addrExeBase ){
			size_t addrCodeSection = hxdw_GetModuleSectionVAddress( hMod, szSecName );
			if( addrCodeSection ){
				size_t addr_to_poke = addrExeBase + addrCodeSection + uInSectionOffset;
				return (void*)addr_to_poke;
			}
		}
	}
	return nullptr;
}
/**
	Returns parent process list, given process id.
	First id in the returned container is the id of the most
	immediate parent.

	\verbatim
		Given following processes list:

			notepad.exe        1220
			notepad.exe        1652
			cmd.exe            1653
			- cmd.exe          3248
			-   program.exe    4336
			-     calc.exe     4908
			firefox.exe        3280

		Called with the PID of the "calc.exe", 4908, returned
		will be the following list of process identifiers:
			[4336,3248,1653]
	\endverbatim
*/
std::vector<uint32_t>
hxdw_GetParentProcessIdentifiers( uint32_t pid_ )
{
	const DWORD pid2 = static_cast<DWORD>( pid_ );
	assert( pid2 );
	std::vector<uint32_t> outp;
	{
		uint32_t pid4 = pid2;
		PROCESSENTRY32 en2;
		for(; pid4 && (en2 = hxdw_GetProcessEntryStruct( pid4 )).th32ProcessID; ){
			if( en2.th32ParentProcessID ){
				outp.push_back( en2.th32ParentProcessID );
			}
			pid4 = en2.th32ParentProcessID;
		}
	}
	return outp;
}
void hxdw_EnumerateSystemProcesses( std::function<bool( const PROCESSENTRY32& inp )> calb2 )
{
	//hxdw_GetProcessEntryStruct

	//	typedef struct tagPROCESSENTRY32 {
	//	  DWORD     dwSize;
	//	  DWORD     cntUsage;
	//	  DWORD     th32ProcessID;
	//	  ULONG_PTR th32DefaultHeapID;
	//	  DWORD     th32ModuleID;
	//	  DWORD     cntThreads;
	//	  DWORD     th32ParentProcessID;
	//	  LONG      pcPriClassBase;
	//	  DWORD     dwFlags;
	//	  CHAR      szExeFile[MAX_PATH];
	//	} PROCESSENTRY32;

	PROCESSENTRY32 prentr;
	prentr.dwSize = sizeof(PROCESSENTRY32);
	HANDLE snapshott = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	if( Process32First( snapshott, &prentr ) ){
		while ( Process32Next( snapshott, &prentr ) ){
			if( !calb2( prentr ) )
				break;
		}
	}
	CloseHandle( snapshott );
}
std::vector<uint32_t>
hxdw_GetChildProcessIdentifiers( uint32_t pid_, const char* flags3 )
{
	const DWORD pid2 = static_cast<DWORD>( pid_ );
	assert( pid2 );
	const bool bRcv = strchr( flags3, 'r' );
	std::vector<uint32_t> outp;
	hxdw_EnumerateSystemProcesses(
		[&]( const PROCESSENTRY32& en2 ){
			if( en2.th32ParentProcessID == pid2 ){
				outp.push_back( en2.th32ProcessID );
			}
			return 1L;
	});
	if( bRcv ){
		std::vector<uint32_t> out2;
		for( auto ir2 = outp.begin(); ir2 != outp.end(); ++ir2 ){
			std::vector<uint32_t> out3;
			out3 = hxdw_GetChildProcessIdentifiers( *ir2, flags3 );
			out2.insert( out2.end(), out3.begin(), out3.end() );
		}
		outp.insert( outp.end(), out2.begin(), out2.end() );
	}
	return outp;
}
/**
	Returns structure.
	On error, member 'th32ProcessID' is set to 0.
*/
PROCESSENTRY32 hxdw_GetProcessEntryStruct( uint32_t pid_ )
{
	const DWORD pid2 = static_cast<DWORD>( pid_ );
	assert( pid2 );
	PROCESSENTRY32 out2;
	memset( &out2, 0, sizeof(PROCESSENTRY32) );
	hxdw_EnumerateSystemProcesses(
		[&]( const PROCESSENTRY32& en2 ){
			//en2.th32ParentProcessID//en2.szExeFile;
			if( en2.th32ProcessID == pid2 ){
				out2 = en2;
				return 0L;
			}
			return 1L;
	});
	return out2;
}
std::vector<uint32_t>
hxdw_GetProcessThreads( uint32_t pid_ )
{
	const DWORD pid2 = static_cast<DWORD>( pid_ );
	assert( pid2 );
	std::vector<uint32_t> out3;
	{
		THREADENTRY32 thentr;
		thentr.dwSize = sizeof(THREADENTRY32);
		HANDLE snapshott = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, NULL);
		if( Thread32First( snapshott, &thentr ) ){
			while ( Thread32Next( snapshott, &thentr ) ){
				if( pid2 == thentr.th32OwnerProcessID ){
					out3.push_back( thentr.th32ThreadID );
				}
			}
		}
		CloseHandle( snapshott );
	}
	return out3;
}
/// Returns window handle, the HWND, or 0 if not found.
void* hxdw_FindParentCMDWindow( uint32_t pid2, uint32_t* pPidOu, const char* flags2 )
{
	pid2 = (pid2 ? pid2 : GetCurrentProcessId());
	if(pPidOu)
		*pPidOu = 0;
	auto aPids = hxdw_GetParentProcessIdentifiers( pid2 );
	for( auto ir2 = aPids.begin(); ir2 != aPids.end(); ++ir2 ){
		PROCESSENTRY32 en2 = hxdw_GetProcessEntryStruct( *ir2 );
		if( !lstrcmpi( en2.szExeFile, "cmd.exe" ) ){
			HWND hwnd = hxdw_FindMainWindowGivenPID( en2.th32ProcessID, flags2 );
			if(pPidOu)
				*pPidOu = en2.th32ProcessID;
			return hwnd;
		}
	}
	return 0;
}
/// Returns window handle, the HWND, or 0 if not found.
void* hxdw_FindChildCMDWindow( uint32_t pid_, uint32_t* pPidOu, const char* flags2 )
{
	std::vector<uint32_t> aChPids;
	aChPids = hxdw_GetChildProcessIdentifiers( pid_, "r" );
	for( auto ir2 = aChPids.begin(); ir2 != aChPids.end(); ++ir2 ){
		PROCESSENTRY32 en2 = hxdw_GetProcessEntryStruct( *ir2 );
		if( !lstrcmpi( en2.szExeFile, "cmd.exe" ) ){
			HWND hwnd = hxdw_FindMainWindowGivenPID( en2.th32ProcessID, flags2 );
			if(pPidOu)
				*pPidOu = en2.th32ProcessID;
			return hwnd;
		}
	}
	return 0;
}
/**
	Reads Image-NT-Header structure from the executable file, which can be EXE or DLL.
	REF:
		https://stackoverflow.com/a/971715
		https://stackoverflow.com/questions/971689/win32-api-to-tell-whether-a-given-binary-exe-or-dll-is-x86-x64-or-ia64
		https://learn.microsoft.com/en-us/windows/win32/api/dbghelp/nf-dbghelp-imagentheader?redirectedfrom=MSDN
		https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-image_nt_headers32
*/
bool hxdw_GetPEImageNtHeadersStruct2( const char* szFileName,
		std::function<void( const IMAGE_NT_HEADERS* inp )> calb2, std::string* err_ )
{
	std::string sink2, &err2 = ( err_ ? *err_ : sink2 );
	HANDLE hFile = 0, hMap2 = 0;
	void* pMapAddr = 0;
	std::shared_ptr<void> raii2( 0, [&]( void* ){
		if( pMapAddr ){
			UnmapViewOfFile( pMapAddr );
			pMapAddr = 0;
		}
		if( hMap2 && hMap2 != INVALID_HANDLE_VALUE ){
			CloseHandle( hMap2 );
			hMap2 = 0;
		}
		if( hFile && hFile != INVALID_HANDLE_VALUE ){
			CloseHandle( hFile );
			hFile = 0;
		}
	});
	hFile = CreateFileA( szFileName, GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );
	if( !hFile || hFile == INVALID_HANDLE_VALUE ){
		err2 = "File open failed [AN7dCQ]";
		return 0L;
	}
	// map the file to our address space first, create a file mapping object
	hMap2 = CreateFileMapping(
			hFile,
			nullptr,           // security attrs
			PAGE_READONLY,     // protection flags
			0,                 // max size - high DWORD
			0,                 // max size - low DWORD
			nullptr );         // mapping name - not used
	if( !hMap2 || hMap2 == INVALID_HANDLE_VALUE ){
		err2 = "Creating file mapping failed [BvkrYI]";
		return 0L;
	}
	// next, map the file to our address space
	pMapAddr = MapViewOfFileEx(
			hMap2,             // mapping object
			FILE_MAP_READ,     // desired access
			0,                 // loc to map - hi DWORD
			0,                 // loc to map - lo DWORD
			0,                 // # bytes to map - 0=all
			nullptr );         // suggested map addr
	if( !pMapAddr ){
		err2 = "Mapping into address space failed [OPDQ0g]";
		return 0L;
	}
	IMAGE_NT_HEADERS* lpPeHdr = 0;
	lpPeHdr = ImageNtHeader( pMapAddr );   // ImageNtHeader(): DbgHelp.dll 5.1 or later.
	if( !lpPeHdr ){
		err2 = "Locating the NT-header structure failed [CCPgUY]";
		return 0L;
	}
	//lpPeHdr->OptionalHeader
	//lpPeHdr->FileHeader.Machine
	calb2( lpPeHdr );
	return 1L;
}
/**
	Returns architecture of the executable file, which can be EXE or DLL.
	Uses functions from DbgHelp.dll|lib.
	\return - 0: error, 32: x86, 64: x64, 70: Intel Itanium.
	\sa hxdw_GetBinaryType()
*/
int32_t hxdw_GetBinaryType3( const char* szFileName, const char* flags2_ )
{
	int32_t uMachine2 = 0;
	hxdw_GetPEImageNtHeadersStruct2( szFileName,
		[&]( const IMAGE_NT_HEADERS* inp ){
			const uint32_t uMachine3 = inp->FileHeader.Machine;
			if( uMachine3 == IMAGE_FILE_MACHINE_I386 ){ //x86|win32
				uMachine2 = 32;
			}else if( uMachine3 == IMAGE_FILE_MACHINE_AMD64 ){ //x64|win64
				uMachine2 = 64;
			}else if( uMachine3 == IMAGE_FILE_MACHINE_IA64 ){ //Intel Itanium
				uMachine2 = 70;
			}
	}, nullptr );
	return uMachine2;
}
